package TrusZamojski;


import java.awt.*;
import java.io.*;
import java.util.Scanner;
import java.util.Random;
import java.util.ArrayList;
import java.util.List;
import java.io.IOException;
import java.io.FileReader;
import java.io.BufferedReader;
import java.io.FileNotFoundException;

public class App {


    private static List<Integer> listaLotto = new ArrayList<Integer>();
    private static List<Integer> listaEuroJackpot = new ArrayList<Integer>();

    public static void  main(String[] args) {

        listaEuroJackpot.clear();
        listaLotto.clear();
        Scanner odczyt = new Scanner(System.in);
        int gra;
        String imie;
        String nazwisko;
        String miejscowosc;
        int liczbylotto[] = new int[6];
        int liczbapom;
        int liczbyEuroJackpot[] = new int[7];
        int tab_odp_lotto[] = new int [6];
        int tab_odp_EuroJackpot[] = new int [6];
        int counter = 0;
        int counter2 = 0;


        System.out.println("Podaj imie: ");
        imie = odczyt.nextLine();

        System.out.println("Podaj nazwisko: ");
        nazwisko = odczyt.nextLine();

        System.out.println("Podaj miejscowosc: ");
        miejscowosc = odczyt.nextLine();

        System.out.println("W co chcesz zagrac? \n 1.Lotto\n 2.EuroJackpot \n 3.Statystyki");
        gra = odczyt.nextInt();

        while(gra < 1 || gra >3) {
            System.out.println("Niewlasciwy numer gry");
            gra = odczyt.nextInt();
        }


        switch (gra) {
            case 1:
                Lotto();

                for (int l = 0; l < liczbylotto.length; l++) {

                    System.out.println("Podaj " + (l + 1) + " liczbe z 49: ");
                    liczbapom = odczyt.nextInt();

                    for (int p = 0; p < liczbylotto.length; p++) {
                        while (liczbapom == liczbylotto[p]) {
                            System.out.println("Liczba " + liczbapom + " juz wystapila!\n Podaj jeszcze raz: ");
                            liczbapom = odczyt.nextInt();
                        }
                    }


                    if (liczbapom >= 1 && liczbapom <= 49) {
                        liczbylotto[l] = liczbapom;
                    } else {
                        System.out.println("Liczba musi zawierac sie w przedziale od 1 do 49 \n Podaj liczbe: ");
                        liczbapom = odczyt.nextInt();
                        liczbylotto[l] = liczbapom;
                    }
                }


                for (int i = 0; i < 6; i++) tab_odp_lotto[i] = 0;

                for (int i = 0; i < 6; i++) {
                    for (int j = 0; j < 6; j++) {
                        if (liczbylotto[i] == listaLotto.get(j)) {
                            tab_odp_lotto[i] += 1;
                            counter++;
                        }
                    }
                }

                System.out.println("Trafiles: " + counter);

                try {
                    BufferedWriter out;
                    out = new BufferedWriter(new FileWriter("BazaDanych.txt", true));
                    out.write("Liczby z losowania Lotto " + listaLotto + " " + imie + " " + nazwisko + " z " + miejscowosc + " trafił " + counter);
                    out.newLine();


                    out.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }


                break;

            case 2:
                EuroJackpot();

                for (int l = 0; l < liczbyEuroJackpot.length; l++) {

                    System.out.println("Podaj " + (l + 1) + " liczbe z 50: ");
                    liczbapom = odczyt.nextInt();

                    for (int p = 0; p < liczbyEuroJackpot.length; p++) {
                        while (liczbapom == liczbyEuroJackpot[p]) {
                            System.out.println("Liczba " + liczbapom + " juz wystapila!\n Podaj jeszcze raz: ");
                            liczbapom = odczyt.nextInt();
                        }
                    }


                    if (liczbapom >= 1 && liczbapom <= 50) {
                        liczbyEuroJackpot[l] = liczbapom;
                    } else {
                        System.out.println("Liczba musi zawierac sie w przedziale od 1 do 50 \n Podaj liczbe: ");
                        liczbapom = odczyt.nextInt();
                        liczbylotto[l] = liczbapom;
                    }
                }

                for (int i = 0; i < 6; i++) tab_odp_EuroJackpot[i] = 0;

                for (int i = 0; i < 6; i++) {
                    for (int j = 0; j < 6; j++) {
                        if (liczbyEuroJackpot[i] == listaEuroJackpot.get(j)) {
                            tab_odp_EuroJackpot[i] += 1;
                            counter2++;
                        }
                    }
                }

                System.out.println("Trafiles: " + counter2);

                try {
                    BufferedWriter out;
                    out = new BufferedWriter(new FileWriter("BazaDanych.txt", true));
                    out.write("Liczby z losowania EuroJackpot " + listaEuroJackpot + " " + imie + " " + nazwisko + " z " + miejscowosc + " trafił " + counter2);
                    out.newLine();


                    out.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }

                break;

            case 3:


                FileReader fr = null;
                String linia = "";


                try {
                    fr = new FileReader("BazaDanych.txt");
                } catch (FileNotFoundException e) {
                    System.out.println("Blad odczytu pliku!");
                }

                BufferedReader bfr = new BufferedReader(fr);

                try {
                    while ((linia = bfr.readLine()) != null) {
                        System.out.println(linia);
                    }
                } catch (IOException e) {
                    System.out.println("Blad odczytu pliku!");
                }

                try {
                    fr.close();
                } catch (IOException e) {
                    System.out.println("Blad odczytu pliku!");
                }


                break;



            default:
                System.out.println("Niewlasciwy wybor gry ");
        }


    }




    public static List<Integer> Lotto() {


        int liczby[] = new int[6];
        int liczby2[] = new int[6];
        int k = 0;
        boolean pom = false;
        Random rand = new Random();

        for (int i = 0; i < liczby.length; i++) {
            pom = false;
            liczby[i] = rand.nextInt(49 - 1 + 1) + 1;
            for (int j = 0; j < i; j++) {
                if (liczby[i] == liczby[j]) {
                    pom = true;
                    i--;
                }
            }
            if (pom == false) {
                liczby2[k] = liczby[i];
                k++;
            }

        }

        for (int z = 0; z < liczby2.length; z++)
        {
            listaLotto.add(liczby2[z]);
        }

        return listaLotto;

    }

    public static List<Integer> EuroJackpot() {
        int licz[] = new int[7];
        int licz2[] = new int[7];
        int g = 0;
        boolean pom2 = false;
        Random random = new Random();

        for (int i = 0; i < licz.length; i++) {
            pom2 = false;
            licz[i] = random.nextInt(50 - 1 + 1) + 1;
            for (int j = 0; j < i; j++) {
                if (licz[i] == licz[j]) {
                    pom2 = true;
                    i--;
                }
            }
            if (pom2 == false) {
                licz2[g] = licz[i];
                g++;
            }
        }

        for (int z = 0; z < licz2.length; z++)
        {
            listaEuroJackpot.add(licz2[z]);
        }
        return listaEuroJackpot;
    }

}

